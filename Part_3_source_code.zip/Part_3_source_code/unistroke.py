
class Unistroke:
    def __init__(self, name, point_array, subject, number):
        super(Unistroke, self).__init__()
        self.name = name
        self.point_array = point_array
        self.subject = subject
        self.number = number

